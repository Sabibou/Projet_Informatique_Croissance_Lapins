/* 
  
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "mersenne_twister.h"

//float POURCENT_LITTER[5] = {0.07, 0.27, 0.32, 0.29, 0.05};

typedef struct population{

    struct rabbit* start;
    int nb_rabbit;

}population;

typedef struct rabbit{

    struct rabbit* next;
    struct rabbit* previous;
    int sex; //1 male, 0 femelle
    int age;

}rabbit;


long int rabbit_population_simulation(int nb_months){

    //le premier mois est le nb_couple_this_month
    //et on a un couple jeune
    long int nb_couples_this_month = 1; 
    long int nb_couples_last_month = 0;
    long int to_keep;

    //au commence au deuxieme mois
    for(int i=2; i<=nb_months; i++){

        to_keep = nb_couples_this_month;
        nb_couples_this_month = nb_couples_last_month + nb_couples_this_month;
        nb_couples_last_month = to_keep;
        printf("%ld\n", nb_couples_this_month);
    }

    return nb_couples_this_month;
}



population* create_new_population(){
    
    population* p = malloc(sizeof(population)*1);
    printf("d");
    p->start = NULL;
    p->nb_rabbit = 0;
    return p;
}

/*
un lapin est désigné par un entier :
 - supérieur à 200 le lapin est une femelle
 - supérieur à 100 le lapin est un mâle
*/
rabbit* create_new_rabbit(){

    rabbit* r = malloc(sizeof(rabbit)*1);
    float random = genrand_real1();

    if(random > 0.5){

        r->sex = 0;
    } 
    else{

        r->sex = 1;
    }
    r->age = 0;
    r->next = NULL;
    r->previous = NULL;

    return r;

}

void add_rabbit(population* p, rabbit* r){

    if(p->start == NULL){

        p->start = r;
    }
    else{

        rabbit* current_r = p->start;
        while(current_r->next != NULL){

            current_r = current_r->next;
        }

        current_r->next = r;
        r->previous = current_r;
    }
}

void delete_rabbit(population* p, rabbit* r){

    if(r->previous != NULL){

        rabbit* temp = r->previous;
        temp->next = r->next;
        r->next->previous = temp; 
    }
    else{

        p->start = r->next;
        r->next->previous = NULL;
    }

    free(r);
}
/*
int nb_litter_per_year(){

    double draw;
    int j;

    double * cumulative_prob = malloc(sizeof(double) * 5); //tableau de densité cumulative
    int * nb_per_litter = malloc(sizeof(double) * 5);  //tableau de la population de chaque classe

    for(int i=0; i<5; i++){

        nb_per_litter[i] = 0;  //on initialise à 0 la population de chaque classe
    }

    cumulative_prob[0] = POURCENT_LITTER[0];

    for(int i=1; i<5; i++){

        cumulative_prob[i] = cumulative_prob[i-1] + POURCENT_LITTER[i];
    }

    for(int i=0; i<1000; i++){

        draw = genrand_real1();
        j=0;

        while(j < 5){
             
            if(draw <= cumulative_prob[j]){  //si le nombre tiré est inférieur ou égale à la densité cumulative de la classe j
                nb_per_litter[j]++;      //on incrémente la population de la classe j
                break;
            }
            
            j++;
        }
    }

    int index_max = 0;
    for(int i=0; i<5; i++){

        if(nb_per_litter[i] > nb_per_litter[index_max]){

            index_max = i;
        }
    }

    free(nb_per_litter);
    free(cumulative_prob);

    return index_max + 4;
}
*/
void gave_birth(population* p){

    if(genrand_real1() > 0.2){

         int number_rabbits = genrand_int32() % 4 + 3;  
         
         for(int i=0; i<number_rabbits; i++){

             add_rabbit(p, create_new_rabbit());
             p->nb_rabbit++;
         }
    }

}

void death(population*p, rabbit* r){

    int age = r->age/12;
    float survival_rate = genrand_real1();

    if(age > 6){

        if((survival_rate + ((float)(age%10)/10)) > 0.6){

            delete_rabbit(p, r); //meurt
            p->nb_rabbit--;
        }
    }
    /*
    else if(p->population[index]%100 > 0){

        if(genrand_real1() > 0.6){

            p->population[index] = 0; //meurt
        }
    }
    */
    else{

        if(survival_rate < 0.35){

            delete_rabbit(p, r); //meurt
            p->nb_rabbit--;
        }
    }
}

void get_older(rabbit* r){

    r->age++;
}

void life(population* p, int months){

    int current_month = 0;

    while(current_month < months && p->nb_rabbit > 0){

        int index = p->nb_rabbit;
        rabbit* current_r = p->start;

        for(int i=0; i<index; i++){  //on verifie que les lapins qui taient nes avant cette année

            death(p, current_r);

            if(current_r->age > 6 && current_r->sex ==0 ){  //si le lapin est une femelle et adulte

                gave_birth(p);
                //printf("naissance\n");
            
            }

            get_older(current_r);
            //printf("get_older\n");
            
            current_r = current_r->next;
        }
        current_month++;
        
    } 
}

int main(){

    unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
    init_by_array(init, length); 

    //printf("%ld\n", rabbit_population_simulation(10));

    population* p1 = create_new_population();
    printf("d");

    printf("d");

    rabbit* r1 = create_new_rabbit();
    add_rabbit(p1, r1);
    r1->sex = 0;
    r1->age = 13;

    rabbit* r2 = create_new_rabbit();
    add_rabbit(p1, r2);
    r2->sex = 0;
    r2->age = 13;

    rabbit* r3 = create_new_rabbit();
    add_rabbit(p1, r3);
    r3->sex = 0;
    r3->age = 13;

    p1->nb_rabbit = 3;

    life(p1, 12);
    printf("nb lapins : %d\n", p1->nb_rabbit);

    return 0;
}
